What to send
Send this whole Temp_Packages folder as one zip.
Do not send the two tex files alone. They will
not compile alone.

Contents
Ruel_Anderson_Second_Derivatve.tex and pdf.
The Rubel and Anderson paper, 7 pages.
Uniform_Real_Zero_Bounds_Constant.tex and pdf.
The Shapiro uniform bounds paper, 11 pages.
KEP_Template.tex and pdf, plus build.sh and
KEP_Style_info.txt. The template reference.
packages, 178 files, 21M. flexart.sty,
stylelibrary.tex, tcolorbox, tikz, and all
support files. Both papers input
stylelibrary.tex from this folder.

How to compile
Put the tex files beside packages, as here.
Run each paper twice with packages on the
TeX search path. In this folder, run
TEXINPUTS=".:packages:" pdflatex
-interaction=nonstopmode -halt-on-error
on the tex file, then run it again.
Plain pdflatex with no TEXINPUTS fails.
It cannot find flexart.sty.

No other files are needed. Neither paper
uses outside figures or a bib file.
References sit inside each tex file.
