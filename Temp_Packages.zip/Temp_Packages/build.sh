#!/bin/sh
# Build KEP_Template.tex. Package and formatting
# files live in packages/, so put that folder on
# the TeX search path. Plain pdflatex without
# this fails on tcbbreakable.code.tex.
set -e
cd "$(dirname "$0")"
export TEXINPUTS=".:packages:${TEXINPUTS:-}"
pdflatex -interaction=nonstopmode -halt-on-error KEP_Template.tex
pdflatex -interaction=nonstopmode -halt-on-error KEP_Template.tex
